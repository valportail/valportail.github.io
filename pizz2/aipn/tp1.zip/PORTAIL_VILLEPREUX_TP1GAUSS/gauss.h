#ifndef __GAUSS_H__

#define __GAUSS_H__


#define VECTEUR_COLONNE 0
#define TAILLE_MATRICE 3


double valeurAbsolue(double);
int permutationLigne(double **, unsigned int , unsigned int , unsigned int );
double ** methodeDeGauss(double **, unsigned int, double **, double);



#endif
