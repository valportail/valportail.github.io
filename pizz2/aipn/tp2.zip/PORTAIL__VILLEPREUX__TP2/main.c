/**
 * @file main.c
 * @brief Contients l'appelle des fonctions pour appliquer l'algorithme de Jacobi ou de Gauss Seidel.
 * @author Valentin PORTAIL et Jérémie VILLEPREUX
 * @version 1.0
 * @date 02/10/2022
 */

#include "matriceTest.h"
#include"methodeJ_GS.h"

	/* Définition des constantes de préprocesseur */
/** \def PRECISION
 * @brief Correspond à la tolérance d'écart que l'on s'autorise par rapport à la solution exacte.
 */
#define PRECISION pow(10, -6)

/** \def ITE_MAX
 * @brief Correspond au nombre d'itération maximal que l'on s'autorise (si non convergence).
 */
#define ITE_MAX 512


/* ==========================================================================
      CETTE PARTIE N'EST JUSTE QU'UN MENU POUR LE CHOIX DES MATRICES TESTS
            **********************************************************
    
   Nous avons décidé d'implémenter le choix de la matrice à l'aide d'un'switch'.
   Le code peut paraître assez lourd, mais il se contente d'appeler et
   d'appliquer une méthode itérative à la matrice test sélectionné, ainsi que
   d'afficher les matrices du sytème, du second membre du sytème et l'unique 
   matrice solution.
   ========================================================================== */



int main(){

    
    int choix_methode = 0;
    int choix_matrice = 0;

    printf("Bienvenu,\n\n");
    printf("Le menu suivant propose d'appliquer la méthode itérative de votre choix (Jacobiou Gauss Seidel) sur les différentes matrices tests  proposées.\n");

    printf("Vous choisirez dans un premier temps la méthode, puis dans un second temps la matrice test voulue.\n\n");

    printf("Menu:\n");
    printf("1. Choix de la méthode de Jacobi.\n");
    printf("2. Applique la méthode de Gauss Seidel.\n");

    printf("Quel est votre choix ? ");
    scanf("%d", &choix_methode);

    printf("\n");
    
    printf("\t> Le premier chiffre du menu correspond au numéro de la matrice proposées.\n");

    printf("\t> Le second (et troisième) chiffre (non nécessaire pour les choix 1 à 4), correspond à la taille de départ pour les matrices A5 et A6.\n");

    printf("Par exemple :\n");
    printf("\t >>> Le choix '3' va appliquer la méthode de Gauss à la matrice A3.\n");
    printf("\t >>> Le choix '56' va appliquer la méthode de Gauss à la matrice A5 en dimension 6.\n");

    printf("\n\n");


    printf("Menu:\n");
    printf("1. Appliquer à la matrice A1.\n");
    printf("2. Appliquer à la matrice A2.\n");
    printf("3. Appliquer à la matrice A3.\n");
    printf("4. Appliquer à la matrice A4.\n");
    printf("53. Appliquer à la matrice A5 en taille 3.\n");
    printf("56. Appliquer à la matrice A5 en taille 6.\n");
    printf("58. Appliquer à la matrice A5 en taille 8.\n");
    printf("510. Appliquer à la matrice A5 en taille 10.\n");
    printf("63. Appliquer à la matrice A6 en taille 3.\n");
    printf("66. Appliquer à la matrice A6 en taille 6.\n");
    printf("68. Appliquer à la matrice A6 en taille 6.\n");
    printf("610. Appliquer à la matrice A6 en taille 10.\n\n");

    printf("Quel est votre choix ? ");

    scanf("%d", &choix_matrice);

    printf("\n");

    switch(choix_methode){

    case 1:{

	switch(choix_matrice){
	
	case 1:{
	    // MATRICE A1
	    double **A1=matriceA1Dynamique();
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A1, TAILLE_MATRICE, TAILLE_MATRICE);
	    double **B1=matriceB1Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B1, TAILLE_MATRICE, 1);
	    message_diagonale_strict_dom(A1, choix_matrice, TAILLE_MATRICE, TAILLE_MATRICE);
	    double **X1=methode_jacobi(A1, B1, TAILLE_MATRICE, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X1, TAILLE_MATRICE, 1);

	    liberationMemoireMatrice(A1, TAILLE_MATRICE);
	    liberationMemoireMatrice(B1, TAILLE_MATRICE);
	    liberationMemoireMatrice(X1, TAILLE_MATRICE);   
	    break;
	}

	    
	case 2:{
	    // MATRICE A2    
	    double **A2=matriceA2Dynamique();
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A2, TAILLE_MATRICE, TAILLE_MATRICE);
	    double**B2=matriceB2Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B2, TAILLE_MATRICE, 1);
	    message_diagonale_strict_dom(A2, choix_matrice,TAILLE_MATRICE, TAILLE_MATRICE);
	    double **X2=methode_jacobi(A2, B2, TAILLE_MATRICE, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X2, TAILLE_MATRICE, 1);

	    liberationMemoireMatrice(A2, TAILLE_MATRICE);
	    liberationMemoireMatrice(B2, TAILLE_MATRICE);
	    liberationMemoireMatrice(X2, TAILLE_MATRICE);
	    break;
	}

	    
	case 3:{
	    // MATRICE A3
	    double **A3=matriceA3Dynamique();
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A3, TAILLE_MATRICE, TAILLE_MATRICE);
	    double**B3=matriceB3Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B3, TAILLE_MATRICE, 1);
	    message_diagonale_strict_dom(A3, choix_matrice, TAILLE_MATRICE, TAILLE_MATRICE);
	    double **X3=methode_jacobi(A3, B3, TAILLE_MATRICE, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X3, TAILLE_MATRICE, 1);

	    liberationMemoireMatrice(A3, TAILLE_MATRICE);
	    liberationMemoireMatrice(B3, TAILLE_MATRICE);
	    liberationMemoireMatrice(X3, TAILLE_MATRICE);
	    break;
	}
	    
	    
	case 4:{
	    // MATRICE A4    
	    double **A4=matriceA4Dynamique();
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A4, TAILLE_MATRICE, TAILLE_MATRICE);
	    double**B4=matriceB4Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B4, TAILLE_MATRICE, 1);
	    message_diagonale_strict_dom(A4, choix_matrice, TAILLE_MATRICE, TAILLE_MATRICE);
	    double **X4=methode_jacobi(A4, B4, TAILLE_MATRICE, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X4, TAILLE_MATRICE, 1);

	    liberationMemoireMatrice(A4, TAILLE_MATRICE);
	    liberationMemoireMatrice(B4, TAILLE_MATRICE);
	    liberationMemoireMatrice(X4, TAILLE_MATRICE);
	    break;
	}

	    
	case 53:{
	
	    // MATRICE A5_3    
	    double **A5_3=matriceA5Dynamique(TAILLE_MATRICE);
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A5_3, TAILLE_MATRICE, TAILLE_MATRICE);
	    double**B5_3=matriceB5_3Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B5_3, TAILLE_MATRICE, 1);
	    message_diagonale_strict_dom(A5_3, choix_matrice, TAILLE_MATRICE, TAILLE_MATRICE);
	    double **X5_3=methode_jacobi(A5_3, B5_3, TAILLE_MATRICE, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X5_3, TAILLE_MATRICE, 1);

	    liberationMemoireMatrice(A5_3, TAILLE_MATRICE);
	    liberationMemoireMatrice(B5_3, TAILLE_MATRICE);
	    liberationMemoireMatrice(X5_3, TAILLE_MATRICE);
	    break;
	}

	    
	case 56:{
	    // MATRICE A5_6    
	    double **A5_6=matriceA5Dynamique(6);
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A5_6, 6, 6);
	    double**B5_6=matriceB5_6Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B5_6, 6, 1);
	    message_diagonale_strict_dom(A5_6, choix_matrice, 6, 6);
	    double **X5_6=methode_jacobi(A5_6, B5_6, 6, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X5_6, 6, 1);
    
	    liberationMemoireMatrice(A5_6, 6);
	    liberationMemoireMatrice(B5_6, 6);
	    liberationMemoireMatrice(X5_6, 6);
	    break;
	}

	    
	case 58:{
	    // MATRICE A5_8    
	    double **A5_8=matriceA5Dynamique(8);
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A5_8, 8, 8);
	    double**B5_8=matriceB5_8Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B5_8, 8, 1);
	    message_diagonale_strict_dom(A5_8, choix_matrice, 8, 8);
	    double **X5_8=methode_jacobi(A5_8, B5_8, 8, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X5_8, 8, 1);
    
	    liberationMemoireMatrice(A5_8, 8);
	    liberationMemoireMatrice(B5_8, 8);
	    liberationMemoireMatrice(X5_8, 8);
	    break;
	}
	    

	case 510:{
	
    
	    // MATRICE A5_10    
	    double **A5_10=matriceA5Dynamique(10);
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A5_10, 10, 10);
	    double**B5_10=matriceB5_10Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B5_10, 10, 1);
	    message_diagonale_strict_dom(A5_10, choix_matrice, 10, 10);
	    double **X5_10=methode_jacobi(A5_10, B5_10, 10, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X5_10, 10, 1);

	    liberationMemoireMatrice(A5_10, 10);
	    liberationMemoireMatrice(B5_10, 10);
	    liberationMemoireMatrice(X5_10, 10);
	    break;
	}
	    

	case 63:{
	    // MATRICE A6_3    
	    double **A6_3=matriceA6Dynamique(TAILLE_MATRICE);
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A6_3, TAILLE_MATRICE, TAILLE_MATRICE);
	    double**B6_3=matriceB6_3Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B6_3, TAILLE_MATRICE, 1);
	    message_diagonale_strict_dom(A6_3, choix_matrice, TAILLE_MATRICE, TAILLE_MATRICE);
	    double **X6_3=methode_jacobi(A6_3, B6_3, TAILLE_MATRICE, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X6_3, TAILLE_MATRICE, 1);
	    
	    liberationMemoireMatrice(A6_3, TAILLE_MATRICE);
	    liberationMemoireMatrice(B6_3, TAILLE_MATRICE);
	    liberationMemoireMatrice(X6_3, TAILLE_MATRICE);
	    break;
	}

	    
	case 66:{
	    // MATRICE A6_6    
	    double **A6_6=matriceA6Dynamique(6);
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A6_6, 6, 6);
	    double**B6_6=matriceB6_6Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B6_6, 6, 1);
	    message_diagonale_strict_dom(A6_6, choix_matrice, 6, 6);
	    double **X6_6=methode_jacobi(A6_6, B6_6, 6, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X6_6, 6, 1);

	    liberationMemoireMatrice(A6_6, 6);
	    liberationMemoireMatrice(B6_6, 6);
	    liberationMemoireMatrice(X6_6, 6);
	    break;
	}
	    
	case 68:{
	    // MATRICE A6_8    
	    double **A6_8=matriceA6Dynamique(8);
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A6_8, 8, 8);
	    double**B6_8=matriceB6_8Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B6_8, 8, 1);
	    message_diagonale_strict_dom(A6_8, choix_matrice, 8, 8);
	    double **X6_8=methode_jacobi(A6_8, B6_8, 8, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X6_8, 8, 1);
    
	    liberationMemoireMatrice(A6_8, 8);
	    liberationMemoireMatrice(B6_8, 8);
	    liberationMemoireMatrice(X6_8, 8);
	    break;
	}

	case 610:{
	    // MATRICE A6_10    
	    double **A6_10=matriceA6Dynamique(10);
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A6_10, 10, 10);
	    double**B6_10=matriceB6_10Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B6_10, 10, 1);
	    message_diagonale_strict_dom(A6_10, choix_matrice, 10, 10);
	    double **X6_10=methode_jacobi(A6_10, B6_10, 10, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X6_10, 10, 1);
    
	    liberationMemoireMatrice(A6_10, 10);
	    liberationMemoireMatrice(B6_10, 10);
	    liberationMemoireMatrice(X6_10, 10);
	    break;
	}

	default:
	    printf("Erreur de saisie.\n");	
	}
	
    }
	break;
	
    case 2:{

	switch(choix_matrice){
	case 1:{
	    // MATRICE A1
	    double **A1=matriceA1Dynamique();
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A1, TAILLE_MATRICE, TAILLE_MATRICE);
	    double **B1=matriceB1Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B1, TAILLE_MATRICE, 1);
	    message_diagonale_strict_dom(A1, choix_matrice, TAILLE_MATRICE, TAILLE_MATRICE);
	    double **X1=methode_gauss_seidel(A1, B1, TAILLE_MATRICE, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X1, TAILLE_MATRICE, 1);

	    liberationMemoireMatrice(A1, TAILLE_MATRICE);
	    liberationMemoireMatrice(B1, TAILLE_MATRICE);
	    liberationMemoireMatrice(X1, TAILLE_MATRICE);   
	    break;
	}

	    
	case 2:{
	    // MATRICE A2    
	    double **A2=matriceA2Dynamique();
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A2, TAILLE_MATRICE, TAILLE_MATRICE);
	    double**B2=matriceB2Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B2, TAILLE_MATRICE, 1);
	    message_diagonale_strict_dom(A2, choix_matrice, TAILLE_MATRICE, TAILLE_MATRICE);
	    double **X2=methode_gauss_seidel(A2, B2, TAILLE_MATRICE, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X2, TAILLE_MATRICE, 1);

	    liberationMemoireMatrice(A2, TAILLE_MATRICE);
	    liberationMemoireMatrice(B2, TAILLE_MATRICE);
	    liberationMemoireMatrice(X2, TAILLE_MATRICE);
	    break;
	}

	    
	case 3:{
	    // MATRICE A3
	    double **A3=matriceA3Dynamique();
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A3, TAILLE_MATRICE, TAILLE_MATRICE);
	    double**B3=matriceB3Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B3, TAILLE_MATRICE, 1);
	    message_diagonale_strict_dom(A3, choix_matrice, TAILLE_MATRICE, TAILLE_MATRICE);
	    double **X3=methode_gauss_seidel(A3, B3, TAILLE_MATRICE, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X3, TAILLE_MATRICE, 1);

	    liberationMemoireMatrice(A3, TAILLE_MATRICE);
	    liberationMemoireMatrice(B3, TAILLE_MATRICE);
	    liberationMemoireMatrice(X3, TAILLE_MATRICE);
	    break;
	}
	    
	    
	case 4:{
	    // MATRICE A4    
	    double **A4=matriceA4Dynamique();
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A4, TAILLE_MATRICE, TAILLE_MATRICE);
	    double**B4=matriceB4Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B4, TAILLE_MATRICE, 1);
	    message_diagonale_strict_dom(A4, choix_matrice, TAILLE_MATRICE, TAILLE_MATRICE);
	    double **X4=methode_gauss_seidel(A4, B4, TAILLE_MATRICE, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X4, TAILLE_MATRICE, 1);

	    liberationMemoireMatrice(A4, TAILLE_MATRICE);
	    liberationMemoireMatrice(B4, TAILLE_MATRICE);
	    liberationMemoireMatrice(X4, TAILLE_MATRICE);
	    break;
	}

	    
	case 53:{
	
	    // MATRICE A5_3    
	    double **A5_3=matriceA5Dynamique(TAILLE_MATRICE);
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A5_3, TAILLE_MATRICE, TAILLE_MATRICE);
	    double**B5_3=matriceB5_3Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B5_3, TAILLE_MATRICE, 1);
	    message_diagonale_strict_dom(A5_3, choix_matrice, TAILLE_MATRICE, TAILLE_MATRICE);
	    double **X5_3=methode_gauss_seidel(A5_3, B5_3, TAILLE_MATRICE, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X5_3, TAILLE_MATRICE, 1);

	    liberationMemoireMatrice(A5_3, TAILLE_MATRICE);
	    liberationMemoireMatrice(B5_3, TAILLE_MATRICE);
	    liberationMemoireMatrice(X5_3, TAILLE_MATRICE);
	    break;
	}

	    
	case 56:{
	    // MATRICE A5_6    
	    double **A5_6=matriceA5Dynamique(6);
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A5_6, 6, 6);
	    double**B5_6=matriceB5_6Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B5_6, 6, 1);
	    message_diagonale_strict_dom(A5_6, choix_matrice, 6, 6);
	    double **X5_6=methode_gauss_seidel(A5_6, B5_6, 6, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X5_6, 6, 1);
    
	    liberationMemoireMatrice(A5_6, 6);
	    liberationMemoireMatrice(B5_6, 6);
	    liberationMemoireMatrice(X5_6, 6);
	    break;
	}

	    
	case 58:{
	    // MATRICE A5_8    
	    double **A5_8=matriceA5Dynamique(8);
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A5_8, 8, 8);
	    double**B5_8=matriceB5_8Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B5_8, 8, 1);
	    message_diagonale_strict_dom(A5_8, choix_matrice, 8, 8);
	    double **X5_8=methode_gauss_seidel(A5_8, B5_8, 8, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X5_8, 8, 1);
    
	    liberationMemoireMatrice(A5_8, 8);
	    liberationMemoireMatrice(B5_8, 8);
	    liberationMemoireMatrice(X5_8, 8);
	    break;
	}
	    

	case 510:{
	
    
	    // MATRICE A5_10    
	    double **A5_10=matriceA5Dynamique(10);
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A5_10, 10, 10);
	    double**B5_10=matriceB5_10Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B5_10, 10, 1);
	    message_diagonale_strict_dom(A5_10, choix_matrice, 10, 10);
	    double **X5_10=methode_gauss_seidel(A5_10, B5_10, 10, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X5_10, 10, 1);

	    liberationMemoireMatrice(A5_10, 10);
	    liberationMemoireMatrice(B5_10, 10);
	    liberationMemoireMatrice(X5_10, 10);
	    break;
	}
	    

	case 63:{
	    // MATRICE A6_3    
	    double **A6_3=matriceA6Dynamique(TAILLE_MATRICE);
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A6_3, TAILLE_MATRICE, TAILLE_MATRICE);
	    double**B6_3=matriceB6_3Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B6_3, TAILLE_MATRICE, 1);
	    message_diagonale_strict_dom(A6_3, choix_matrice, TAILLE_MATRICE, TAILLE_MATRICE);
	    double **X6_3=methode_gauss_seidel(A6_3, B6_3, TAILLE_MATRICE, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X6_3, TAILLE_MATRICE, 1);
    
	    liberationMemoireMatrice(A6_3, TAILLE_MATRICE);
	    liberationMemoireMatrice(B6_3, TAILLE_MATRICE);
	    liberationMemoireMatrice(X6_3, TAILLE_MATRICE);
	    break;
	}

	    
	case 66:{
	    // MATRICE A6_6    
	    double **A6_6=matriceA6Dynamique(6);
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A6_6, 6, 6);
	    double**B6_6=matriceB6_6Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B6_6, 6, 1);
	    message_diagonale_strict_dom(A6_6, choix_matrice, 6, 6);
	    double **X6_6=methode_gauss_seidel(A6_6, B6_6, 6, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X6_6, 6, 1);

	    liberationMemoireMatrice(A6_6, 6);
	    liberationMemoireMatrice(B6_6, 6);
	    liberationMemoireMatrice(X6_6, 6);
	    break;
	}
	    
	case 68:{
	    // MATRICE A6_8    
	    double **A6_8=matriceA6Dynamique(8);
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A6_8, 8, 8);
	    double**B6_8=matriceB6_8Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B6_8, 8, 1);
	    message_diagonale_strict_dom(A6_8, choix_matrice, 8, 8);
	    double **X6_8=methode_gauss_seidel(A6_8, B6_8, 8, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X6_8, 8, 1);
    
	    liberationMemoireMatrice(A6_8, 8);
	    liberationMemoireMatrice(B6_8, 8);
	    liberationMemoireMatrice(X6_8, 8);
	    break;
	}

	case 610:{
	    // MATRICE A6_10    
	    double **A6_10=matriceA6Dynamique(10);
	    printf("La matrice A de départ est: \n");
	    afficheMatrice(A6_10, 10, 10);
	    double**B6_10=matriceB6_10Dynamique();
	    printf("La matrice b de départ est: \n");
	    afficheMatrice(B6_10, 10, 1);
	    message_diagonale_strict_dom(A6_10, choix_matrice, 10, 10);
	    double **X6_10=methode_gauss_seidel(A6_10, B6_10, 10, PRECISION, ITE_MAX);
	    printf("La matrice final x pour une precision %le et un nombre d'itération maximal %d est: \n", PRECISION , ITE_MAX);
	    afficheMatrice(X6_10, 10, 1);
    
	    liberationMemoireMatrice(A6_10, 10);
	    liberationMemoireMatrice(B6_10, 10);
	    liberationMemoireMatrice(X6_10, 10);
	    break;
	}

	default:
	    printf("Erreur de saisie.\n");	
	}
	break;
    }
	
    default:
	printf("Erreur de saisie.\n");	
    }
    printf("Fin du programme.\n");
    return EXIT_SUCCESS;
}

