#ifndef __MATRICE_TEST_H__

#define __MATRICE_TEST_H__

	/* Bibliothèque standard */ 
#include<stdio.h>
#include<stdlib.h>
#include<math.h>


	/* Définition des constantes de préprocesseur */
/** \def TAILLE_MATRICE
 * @brief Correspond à la taille de la matrice le plus souvent considérer.
 */
#define TAILLE_MATRICE 3

/** \def VECTEUR_COLONNE
 * @brief Correspond à l'indice des colonnes d'un vecteur colonne.
 */
#define VECTEUR_COLONNE 0

	/* Prototype des fonctions */
int afficheMatrice(double **, unsigned int, unsigned int);
double ** creationMatriceDynamique(unsigned int, unsigned int);
double ** cree_matrice_colonne(unsigned int, double);
int liberationMemoireMatrice(double **, unsigned int);

double ** matriceA1Dynamique(void);
double ** matriceA2Dynamique(void);
double ** matriceA3Dynamique(void);
double ** matriceA4Dynamique(void);
double ** matriceA5Dynamique(unsigned int);
double ** matriceA6Dynamique(unsigned int);

double ** matriceB1Dynamique(void);
double ** matriceB2Dynamique(void);
double ** matriceB3Dynamique(void);
double ** matriceB4Dynamique(void);
double ** matriceB5_3Dynamique(void);
double ** matriceB5_6Dynamique(void);
double ** matriceB5_8Dynamique(void);
double ** matriceB5_10Dynamique(void);
double ** matriceB6_3Dynamique(void);
double ** matriceB6_6Dynamique(void);
double ** matriceB6_8Dynamique(void);
double ** matriceB6_10Dynamique(void);

#endif
