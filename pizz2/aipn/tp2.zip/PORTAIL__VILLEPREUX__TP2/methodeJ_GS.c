/**
 * @file methodeJ_GS.c
 * @brief Contients l'implémentation de la méthode de Gauss.
 * @author Valentin PORTAIL et Jérémie VILLEPREUX
 * @version 1.0
 * @date 02/10/2022
 */

#include"methodeJ_GS.h"


/** 
 * @brief Permet de calculer la valeur absolue d'un flottant.
 *
 * @param[in] nbr      La valeur absolue du nombre à calculer.
 *
 * @return Renvoie la valeur absolue du nombre passé en argument.
 */
double absolu(double nbr){
    if (nbr<0){
	return -1*nbr;
    }
    return nbr;
}

/** 
 * @brief Permet d'ajouter dans un fichier la valeur de l'erreur relative.
 *
 * @param[in] value      La valeur de l'erreur relative à ajouter.
 *
 * @return Renvoie la valeur absolue du nombre passé en argument.
 */
void ecriture_csv(double value){

    FILE * fd = fopen("ErrRel.csv", "a+");

    if (fd == NULL){
	exit(EXIT_FAILURE);
    }

    fprintf(fd,"%lf;", value);

    fclose(fd);
}



/** 
 * @brief Permet de savoir si une matriceest à diagonale strictement dominante.
 *
 * @param[in] A               La matrice  A considérée.
 * @param[in] nbrLigne        Le nombre de ligne de la matrice A.
 * @param[in] nbrColonne      Le nombre de colonne de la matrice A.
 *
 * @return Renvoie 1 si la matrice est à diagonale strictement domianante, 0 sinon.
 */
Bool diagonale_strict_dom(double ** A, unsigned int nbrLigne, unsigned int nbrColonne){
    unsigned int i, j;
    double somme;
    double val_abs_coeff_diag;

    if (A == NULL){                                 //Echec d'allocation (antérieur).
	fprintf(stderr, "Erreur A est NULL.");
	exit(EXIT_FAILURE);
    }

    for (i = 0; i < nbrLigne; ++i){
	
	val_abs_coeff_diag = absolu(A[i][i]);
	somme = 0;
	
	for(j = 0; j < nbrColonne; ++j){
	    if (i != j){
		somme += absolu(A[i][j]);
	    }
	}
	if (somme > val_abs_coeff_diag){
	    return false;                         //Définie dans le fichier methodeJ_GS.h : false := 0, true := 1.
	}
    }
    return true;
}



/** 
 * @brief Affiche sous forme de message (en console) si la marice est à diagoale strictement dominante.
 *
 * @param[in] A               La matrice  A considérée.
 * @param[in] S               Le numéro de la matrice A.
 * @param[in] nbrLigne        Le nombre de ligne de la matrice A.
 * @param[in] nbrColonne      Le nombre de colonne de la matrice A.
 */
void message_diagonale_strict_dom(double ** A, int s, unsigned int nbrLigne, unsigned int nbrColonne){
    while (s>10){
	s /= 10;
    }

    
    if (diagonale_strict_dom(A, nbrLigne, nbrColonne)){
	printf("La matrice A%d est à diagonale strictement dominante.\n", s);
    }
    else {
	printf("La matrice A%d n'est pas à diagonale strictement dominante.\n", s);
    }
}


/** 
 * @brief Permet de calculer l'erreur relative entre la solution exacte **solut** et une solution approchée **x** à partir de la formule donnée dans sujet du TP.
 *
 * @param[in] x            Vecteur colonne de la solution approchée.
 * @param[in] solut        Vecteur colonne de la solution exacte.
 * @param[in] n            Nombre de ligne de la solution exacte/approchée.
 *
 * @return Renvoie l'erreur relative entre la solution exacte **solut** et une solution approchée **x**.
 */
double epsilon(double ** x, double ** solut, unsigned int n) {
    unsigned int i;
    double erreur;
    double p = -1; // Valeur impossible

    for (i = 0; i < n; ++i) {
        erreur = absolu(solut[i][VECTEUR_COLONNE] - x[i][VECTEUR_COLONNE]);
        if (erreur > p) {
            p = erreur;
        }
    }
    return p;
}



/** 
 * @brief Permet d'appliquer l'algorithme de Jacobi sur une matrice A considérée.
 *
 * @param[in] A            Matrice carrée sur laquelle appliquée la méthode de Jacobi.
 * @param[in] b            Matrice  colonne du second membre du sysptème " **Ax = b** ".
 * @param[in] n            Taille de la matrice **A**.
 * @param[in] precision    Tolérence maximale d'écoart entre la solution obtenue et la solution **exacte**.
 * @param[in] ite_max      Nombre d'itération maximal que l'on s'autorise à faire.
 *
 * @return Renvoie un pointeur sur la matrice colonne résultat.
 */
double ** methode_jacobi(double ** A, double ** b, unsigned int n, double precision, unsigned int ite_max){
    unsigned int i, j;
    unsigned int k = 0;
    double somme = 0;

    if (precision < 0){
	fprintf(stderr, "La précision doit être un flottant positif.\n");
	exit(EXIT_FAILURE);
    }

    // x_k
    double ** x = cree_matrice_colonne(n, 0);              //Le vecteur nul est choisi comme solution intiale.
    double ** solut_exacte = cree_matrice_colonne(n, 1);   //La solution exacte est déja connu (vecteur colonne unitaire...).

    if (x == NULL || solut_exacte == NULL){
	return NULL;
    }

    double e = epsilon(x, solut_exacte, n);                //Precision epsilon à l'iteration k(=0).

    while (e >= precision && k < ite_max) {                //Debut de la boucle princpale de l'algorithme de Jacobi.

        // x_k+1
        double ** x_next = cree_matrice_colonne(n, 0);

        for (i = 0; i < n; ++i) {

            somme = 0;
            for (j = 0; j < n; ++j) {
                if (i != j) {
                    somme += A[i][j] * x[j][VECTEUR_COLONNE];
                }
            }

            x_next[i][VECTEUR_COLONNE] = (b[i][VECTEUR_COLONNE] - somme) / A[i][i];
        }

	liberationMemoireMatrice(x, n);
        x = x_next;

	// ecriture_csv(e);                              // Permet d'écrire le résidu dans un fichier csv
	
        e = epsilon(x, solut_exacte, n);              //Nouveau calcul de la precision epsilon à l'itération k (>=1).

        ++k;

    }                                                //Fin de la boucle princpale de l'algorithme de Jacobi.

    // printf("Nombre total d'itérations : %d\n", k);
    // printf("Résidu final : %le\n", e);

    // ecriture_csv(e);	
    liberationMemoireMatrice(solut_exacte, n);
    return x;
}


/** 
 * @brief Permet  d'appliquer l'algorithme de Gauss Seidel sur une matrice A considérée.
 *
 * @param[in] A            Matrice carrée sur laquelle appliquée la méthode de GauSS Seidel.
 * @param[in] b            Matrice  colonne du second membre du sysptème " **Ax = b** ".
 * @param[in] n            Taille de la matrice **A**.
 * @param[in] precision    Tolérence maximale d'écoart entre la solution obtenue et la solution **exacte**.
 * @param[in] ite_max      Nombre d'itération maximal que l'on s'autorise à faire.
 *
 * @return Renvoie un pointeur sur la matrice colonne résultat.
 */
double ** methode_gauss_seidel(double ** A, double ** b, unsigned int n,  double precision, unsigned int ite_max) {
    unsigned int i, j;
    unsigned int k = 0;
    double somme_sup = 0;
    double somme_inf = 0;

    if (precision < 0){
	fprintf(stderr, "La précision doit être un flottant positif.\n");
	exit(EXIT_FAILURE);
    }

    // x_k
    double ** x = cree_matrice_colonne(n, 0);              //Le vecteur nul est choisi comme solution intiale.
    double ** solut_exacte = cree_matrice_colonne(n, 1);   //La solution exacte est déja connu (vecteur colonne unitaire...).

    if (x == NULL || solut_exacte == NULL){
	return NULL;
    }

    double e = epsilon(x, solut_exacte, n);                //Precision epsilon à l'iteration k(=0).

    while (e >= precision && k < ite_max) {                //Debut de la boucle princpale de l'algorithme de Gauss Seidel.

        // x_k+1
        double ** x_next = cree_matrice_colonne(n, VECTEUR_COLONNE);

        for (i = 0; i < n; ++i) {

            somme_inf = 0;
            for (j = 0; j < i; ++j) {
                somme_inf += A[i][j] * x_next[j][VECTEUR_COLONNE];
            }

            somme_sup = 0;
            for (j = i + 1; j < n; ++j) {
                somme_sup += A[i][j] * x[j][VECTEUR_COLONNE];
            }

            x_next[i][VECTEUR_COLONNE] = (b[i][VECTEUR_COLONNE] - somme_inf - somme_sup) / A[i][i];
        }
	liberationMemoireMatrice(x, n);
        x = x_next;
	
	// ecriture_csv(e);                              // Permet d'écrire le résidu dans un fichier csv
        e = epsilon(x, solut_exacte, n);              //Nouveau calcul de la precision epsilon à l'itération k (>=1).

        ++k;

    }                                                //Fin de la boucle princpale de l'algorithme de Gauss Seidel.

    // printf("Nombre total d'itérations : %d\n", k);
    // printf("Résidu final : %le\n", e);

    // ecriture_csv(e);                              
    liberationMemoireMatrice(solut_exacte, n);
    return x;
}

