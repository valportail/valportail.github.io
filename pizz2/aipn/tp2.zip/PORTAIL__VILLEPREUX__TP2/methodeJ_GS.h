#ifndef __METHODEJ_GS_H__

#define __METHODEJ_GS_H__


	/* Bibliothèque standard */
#include"matriceTest.h"



	/* Définition booléen */
/**
 * @bref Définition booléen 
 */
typedef enum{
    false, //0
    true,  //1
} Bool;



	/* Définition des constantes de préprocesseur */
/** \def VECTEUR_COLONNE
 * @brief Correspond à l'indice des colonnes d'un vecteur colonne.
 */
#define VECTEUR_COLONNE 0

/** \def TAILLE_MATRICE
 * @brief Correspond à la taille de la matrice le plus souvent considérer.
 */
#define TAILLE_MATRICE 3


	/* Prototype des fonctions */
double absolu(double);
void ecriture_csv(double);
Bool diagonale_strict_dom(double **, unsigned int, unsigned int);
void message_diagonale_strict_dom(double **, int, unsigned int, unsigned int );
double epsilon(double **, double **, unsigned int);
double ** methode_jacobi(double **, double **, unsigned int, double, unsigned int);
double ** methode_gauss_seidel(double **, double **, unsigned int,  double, unsigned int); 


#endif
