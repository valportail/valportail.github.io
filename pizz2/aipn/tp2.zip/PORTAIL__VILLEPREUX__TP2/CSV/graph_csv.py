#!/usr/bin/env python3
##
# @file graph_csv.py
# @brief Peremt de réaliser les tracés de nos "erreurs relatifs" pour chacune des matrices.
# @author Valentin PORTAIL et Jérémie VILLEPREUX
# @version 1.0
# @date 02/10/2022

# Imports

import numpy as np
import matplotlib.pyplot as plt


def trace(fichierJ, fichierGs):
    """! fait les tracés de Jacobi et Gauss-Seidel sur le même graphe.

    @param fichierJ     Fichier csv qui contient les valeurs des erreurs
    relatifs pour la méthode de Jacobi.
    @param fichierGS   Fichier csv qui contient les valeurs des erreurs relatifs
    pour la méthde de Gauss-Seidel.
    """
    #Jacobi
    
    X_jac = []
    Y_jac = []

    with open(fichierJ, encoding="utf-8") as f:
        for ligne in f:
            donnees = ligne.split(";")
            for (i,x) in enumerate(donnees):
                X_jac.append(i)
                if x == '':
                    #En python un double n'existe pas toujours, il n'est donc pas représentable en machine... => dans donnees il sera considéré comme une chaîne de caractères vide. 
                    x = 0
                Y_jac.append(float(x))
                if i > 150: #valeurs abérrantes et perte de précision
                    break
    
    plt.plot(X_jac, Y_jac, color="red", label = "Jacobi")
    plt.xlabel("k-ième itération")
    plt.ylabel("errreur relative p")
    
    
    plt.yscale("log")
    plt.grid(True, which="both", linestyle='--')
    plt.title("Evolution de l'erreur relative selon l'itération")
    
    X_Gs = []
    Y_Gs = []
    with open(fichierGs, encoding="utf-8") as f:
        for ligne in f:
            donnees = ligne.split(";")
            for (i,x) in enumerate(donnees):
                X_Gs.append(i)
                if x == '':
                    x = 0
                Y_Gs.append(float(x))
                if i > 150: #valeurs abérrantes et perte de précision
                    break
    plt.plot(X_Gs, Y_Gs, color = "blue", label = "Gauss Seidel")
    
    plt.legend()

    plt.show()


if __name__ == "__main__":
    trace("ErrRelA1(J).csv", "ErrRelA1(Gs).csv")
    trace("ErrRelA2(J).csv", "ErrRelA2(Gs).csv")
    trace("ErrRelA3(J).csv", "ErrRelA3(Gs).csv")
    trace("ErrRelA4(J).csv", "ErrRelA4(Gs).csv")
    trace("ErrRelA5_10(J).csv", "ErrRelA5_10(Gs).csv")
    trace("ErrRelA6_10(J).csv", "ErrRelA6_10(Gs).csv")
