/**
 * @file approximation.h
 * @brief Contients les fonctions pour l'approximation via la méthode de regression.
 * @author Valentin PORTAIL et Jérémie VILLEPREUX
 * @version 1.0
 * @date 08/11/2022
 */

#ifndef __APPROXIMATION_H__

#define __APPROXIMATION_H__

float carre(float);

void libere_tab_1d(float *);

void tab_ln(float *, int);

float moyenne(float *, int);

void produit_tab(float *, float *, int);

float *approximation(float *, float *, int);

float *approximation_exp(float *, float *, int);


#endif
