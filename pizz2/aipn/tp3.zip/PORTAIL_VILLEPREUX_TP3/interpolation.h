/**
 * @file interpolation.h
 * @brief Contients les portotypes des fonctions pour l'interpolation.
 * @author Valentin PORTAIL et Jérémie VILLEPREUX
 * @version 1.0
 * @date 08/11/2022
 */

#ifndef __INTERPOLATION_H__

#define __INTERPOLATION_H__

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
double * cree_polynome(unsigned int);
void affiche_polynome(double *, unsigned int);
double * produit_polynomes(double *, double *, unsigned int, unsigned int);
double methode_lagrange(double **, unsigned int, double); 
double methode_neville(double **, unsigned int, double); 
void ecriture_polynome_L(char *, double **, unsigned int, double, double);
void ecriture_polynome_N(char *, double **, unsigned int, double, double);

#endif
