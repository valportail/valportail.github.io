# Imports
import numpy as np
import matplotlib.pyplot as plt


def trace(fichier, fichierP, choix):
    """Fonction pour tracer les polynomes, fichier correspond au fichier des x, f(x) et fichierP contient les poitns initiaux"""
    X, Xp = [], []
    Y, Yp = [], []

    if choix == 1:
        abs = "Densité (t/m**3)"
        ord = "Température (Celsius)"
        titre = "Densité de l'eau en focntion de la température."

        
    elif choix == 2:
        abs = "Revenus des employés"
        ord = "Depense des loisirs mensuels"
        titre = "Relation Revenus des employés/Dépenses de loisirs (mensuels)"

    elif choix == 3:
        abs = "x"
        ord = "y"
        titre = "Serie S dûe à Anscombe"
                

    with open(fichier, encoding="utf-8") as f: #methode vu en Python pour les maths
        for ligne in f:
            donnees = ligne.split(" ")
            X.append(float(donnees[0]))
            Y.append(float(donnees[1]))
            

    plt.plot(X, Y, color="red")
    plt.xlabel(abs)
    plt.ylabel(ord)
    plt.title(titre)
    

    with open(fichierP, encoding="utf-8") as f: #methode vu en Python pour les maths
        for ligne in f:
            donnees = ligne.split(" ")
            Xp.append(float(donnees[0]))
            Yp.append(float(donnees[1]))

   
    

    plt.plot(Xp, Yp, 'b+', label="Points de départ")
    
    plt.legend()
    plt.show()


    

    
if __name__ == "__main__":
    
    #1.
    trace("polynome1_L.txt", "polynome1.txt",1)
    trace("polynome1_N.txt", "polynome1.txt",1)

    #2.
    trace("polynome2_L.txt", "polynome2.txt",2)
    trace("polynome2_N.txt", "polynome2.txt",2)

    #3.
    trace("polynome3_L.txt", "polynome3.txt",3)
    trace("polynome3_N.txt", "polynome3.txt",3)
