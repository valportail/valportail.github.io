package com.uca.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.*;

public class _Connector {

    private static String url = "jdbc:postgresql://localhost/life";
    private static String user = "valentin";
    private static String passwd = "life";

    private static Connection connect;

    private static HashMap<Integer, Connection> connections = new HashMap<>();

    public static Connection getConnection(int session) {
        if (connections.get(session) == null) {
            connections.put(session, getNewConnection());
        }
        return connections.get(session);
    }

    public static void resetConnections() {
        connections.clear();
    }

    public static Connection getMainConnection(){
        if(connect == null){
            connect = getNewConnection();
        }
        return connect;
    }

    private static Connection getNewConnection() {
        Connection c;
        try {
            c = DriverManager.getConnection(url, user, passwd);
            c.setAutoCommit(false);
            c.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
        } catch (SQLException e) {
            System.err.println("Erreur en ouvrant une nouvelle connection.");
            throw new RuntimeException(e);
        }
        return c;
    }
}
