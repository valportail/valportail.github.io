package com.uca.dao;

import java.sql.*;

public class _Initializer {
    // nom de la table contenant la grille
    final static String TABLE = "plateau";
    // taille de grille
    final static int SIZE = 250;

    /**
     * cette méthode permet d'initialiser en créant une table pour la grille si elle n'existe pas
     */
    public static void Init(){
        Connection connection = _Connector.getMainConnection();
        try {
            PreparedStatement statement;

            statement = connection.prepareStatement("DROP TABLE " + TABLE + ";");
            statement.executeUpdate();

            //Init table
            statement = connection.prepareStatement("CREATE TABLE IF NOT EXISTS " + TABLE + " (cooX INTEGER, cooY INTEGER, primary key(cooX, cooY));");
            statement.executeUpdate();

            connection.commit();

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Could not create database!");
        }
    }

    /**
     * teste si une table existe dans la base de données 
     */
    private static boolean tableExists(Connection connection, String tableName) throws SQLException {
        DatabaseMetaData meta = connection.getMetaData();
        ResultSet resultSet = meta.getTables(null, null, tableName, new String[]{"TABLE"});
        return resultSet.next();
    }
}
