package com.uca.dao;

import com.uca.entity.CellEntity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class GridDAO {
    public List<CellEntity> getGrid(int session) throws SQLException {
        Connection connection = _Connector.getConnection(session);

        try {
            List<CellEntity> cells = new ArrayList<>();

            PreparedStatement statement;
            statement = connection.prepareStatement("SELECT cooX, cooY FROM plateau;");

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                CellEntity cell = new CellEntity(resultSet.getInt("cooX"), resultSet.getInt("cooY"));
                cells.add(cell);
            }

            return cells;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException();
        }
    }

    public boolean isAliveCell(int x, int y, int session) throws SQLException {
        Connection connection = _Connector.getConnection(session);

        try {
            PreparedStatement statement;
            statement = connection.prepareStatement("SELECT * FROM plateau WHERE cooX = ? AND cooY = ? ;");
            statement.setInt(1, x);
            statement.setInt(2, y);
            ResultSet resultSet = statement.executeQuery();

            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException();
        }
    }

    public void loadGrid(List<CellEntity> cells, int session) throws SQLException {
        try {
            clear(session);
            for (CellEntity cell : cells) {
                int cooX = cell.getX();
                int cooY = cell.getY();
                addCell(cooX, cooY, session);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException();
        }
    }

    public void addCell(int x, int y, int session) throws SQLException {
        Connection connection = _Connector.getConnection(session);

        try {
            PreparedStatement statement;
            if (isAliveCell(x, y, session)) {
                statement = connection.prepareStatement("DELETE FROM plateau WHERE cooX = ? AND cooY = ?;");
            } else {
                statement = connection.prepareStatement("INSERT INTO plateau(cooX, cooY) VALUES (?, ?);");
            }
            statement.setInt(1, x);
            statement.setInt(2, y);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException();
        }
    }

    public int getNearbyAliveCells(CellEntity cell, int session) throws SQLException {
        try {
            int cooX = cell.getX();
            int cooY = cell.getY();
            int cellsAliveNearby = 0;

            /* Parcours de l'ensemble des cellules adjacentes */
            for (int x = cooX-1; x <= cooX+1; x++) {
                for (int y = cooY-1; y <= cooY+1; y++) {
                    /* On regarde si ce n'est pas la cellule elle-même */
                    if (x != cooX || y != cooY) {
                        if (isAliveCell(x, y, session)) {
                            cellsAliveNearby++;
                        }
                    }
                }
            }
            return cellsAliveNearby;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException();
        }
    }

    public void loadNextGeneration(int session) throws SQLException {
        try {
            List<CellEntity> cellsToModify = new ArrayList<>();
            List<CellEntity> cellsAlive = getGrid(session);
            Set<CellEntity> cellsDead = new HashSet<>();

            /* Cas des cellules vivantes */
            for (CellEntity c : cellsAlive) {
                int cooX = c.getX();
                int cooY = c.getY();
                int cellsAliveNearby = 0;
                for (int x = cooX-1; x <= cooX+1; x++) {
                    for (int y = cooY-1; y <= cooY+1; y++) {
                        if (x != cooX || y != cooY) {
                            if (isAliveCell(x, y, session)) { // Si la cellule est vivante
                                cellsAliveNearby++;
                            } else {
                                cellsDead.add(new CellEntity(x, y));
                            }
                        }
                    }
                }

                /* 1re règle du jeu de la vie :
                   Une cellule vivante ne survit que si elle est entourée par 2 ou 3 cellules vivantes.
                   Sinon, elle meurt. */
                if (cellsAliveNearby < 2 || cellsAliveNearby > 3) {
                    cellsToModify.add(c);
                }
            }

            /* Cas des cellules mortes */
            for (CellEntity c : cellsDead) {
                int cellsAliveNearby = getNearbyAliveCells(c, session);
                /* 2e règle du jeu de la vie :
                   Une cellule morte ne renaît que si elle est entourée par 3 cellules vivantes.
                   Sinon, elle reste morte. */
                if (cellsAliveNearby == 3) {
                    cellsToModify.add(c);
                }
            }

            /* Modification des cellules de la grille */
            for (CellEntity c : cellsToModify) {
                addCell(c.getX(), c.getY(), session);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException();
        }
    }

    public void clear(int session) throws SQLException {
        Connection connection = _Connector.getConnection(session);

        try {
            PreparedStatement statement;
            statement = connection.prepareStatement("DELETE FROM plateau;");
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException();
        }
    }

    public void commit(int session) throws SQLException {
        Connection connection = _Connector.getConnection(session);

        try {
            connection.commit();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException();
        }
    }

    public void rollback(int session) throws SQLException {
        Connection connection = _Connector.getConnection(session);

        try {
            connection.rollback();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException();
        }
    }
}
