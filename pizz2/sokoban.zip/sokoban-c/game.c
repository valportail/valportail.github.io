#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "levels.h"

typedef struct coordonnees {
    int x;
    int y;
} coord;

coord * trouve_joueur(char ** laby, int hauteur, int largeur) {
    coord * emplacement = malloc(sizeof(coord));
    emplacement -> x = 0;
    emplacement -> y = 0;

    int i, j;
    for (i = 0; i < hauteur; ++i) {
        for (j = 0; j < largeur; ++j) {
            if (laby[i][j] == 'P') {
                emplacement -> x = i;
                emplacement -> y = j;
            }
        }
    }

    return emplacement;
}

int deplace_joueur_H(coord * P, char ** laby, char ** ref, int largeur, int dir_H, int * caisses, int * score) {

    int i = P -> x;
    int j = P -> y;

    if ((j + dir_H < 0 || j + dir_H > largeur) || laby[i][j + dir_H] == '#') {

        return 0;

    } else if ((j + 2*dir_H > 0 && j + 2*dir_H < largeur) && (laby[i][j + dir_H] == 'C' || laby[i][j + dir_H] == 'B')) {

        if (laby[i][j + 2*dir_H] != ' ' && laby[i][j + 2*dir_H] != 'I') {

            return 0;

        } else {

            ++(*score);

            // Déplacement de la caisse
            if (ref[i][j + dir_H] == ' ' && ref[i][j + 2*dir_H] == 'I') {
                laby[i][j + 2*dir_H] = 'B';
                --(*caisses);
            } else if (ref[i][j + dir_H] == ' ' && ref[i][j + 2*dir_H] == 'I') {    
                laby[i][j + 2*dir_H] = 'C';
                ++(*caisses);
            } else {
                laby[i][j + 2*dir_H] = laby[i][j + dir_H];
            }
            
            // Déplacement du personnage
            laby[i][j + dir_H] = 'P';
            laby[i][j] = ref[i][j];

            P -> y = j + dir_H;

            return 1;

        }

    } else {

        laby[i][j + dir_H] = 'P';
        laby[i][j] = ref[i][j];

        P -> y = j + dir_H;

        return 1;

    }
}

int deplace_joueur_V(coord * P, char ** laby, char ** ref, int hauteur, int dir_V, int * caisses, int * score) {

    int i = P -> x;
    int j = P -> y;

    if ((i + dir_V < 0 || i + dir_V > hauteur) || laby[i + dir_V][j] == '#') {

        return 0;

    } else if ((i + 2*dir_V > 0 && i + 2*dir_V < hauteur) && (laby[i + dir_V][j] == 'C' || laby[i + dir_V][j] == 'B')) {

        if (laby[i + 2*dir_V][j] != ' ' && laby[i + 2*dir_V][j] != 'I') {

            return 0;

        } else {

            ++(*score);

            // Déplacement de la caisse
            if (ref[i + dir_V][j] == ' ' && ref[i + 2*dir_V][j] == 'I') {
                laby[i + 2*dir_V][j] = 'B';
                --(*caisses);
            } else if (ref[i + dir_V][j] == ' ' && ref[i + 2*dir_V][j] == 'I') {
                laby[i + 2*dir_V][j] = 'C';
                ++(*caisses);
            } else {
                laby[i + 2*dir_V][j] = laby[i + dir_V][j];
            }
            
            // Déplacement du personnage
            laby[i + dir_V][j] = 'P';
            laby[i][j] = ref[i][j];

            P -> x = i + dir_V;

            return 1;

        }

    } else {

        laby[i + dir_V][j] = 'P';
        laby[i][j] = ref[i][j];

        P -> x = i + dir_V;

        return 1;

    }
}

void jeu(map niveau, map ref) {
    system("clear");

    coord * emplacement_P = trouve_joueur(niveau.tableau, niveau.h, niveau.l);

    char touche[2];
    int mouvement = 1;

    int score = 0;

    time_t temps_debut = time(NULL);

    printf("Niveau chargé. Commencez à jouer. ");

    while (niveau.c != 0) {
        fgetc(stdin); // stdin contient encore la touche "entrée" utilisée plus tôt

        printf("%d caisse(s) restante(s).\n", niveau.c);
        printf("%d mouvements.\n\n", score);

        affiche_map(niveau);

        printf("Quel est votre prochain coup ? ");
        fgets(touche, 2, stdin);

        system("clear");

        if (touche[0] == 'g' || touche[0] == 'q') {
            mouvement = deplace_joueur_H(emplacement_P, niveau.tableau, ref.tableau, niveau.l, -1, &niveau.c, &score);
        } else if (touche[0] == 'd') {
            mouvement = deplace_joueur_H(emplacement_P, niveau.tableau, ref.tableau, niveau.l, 1, &niveau.c, &score);
        } else if (touche[0] == 'h' || touche[0] == 'z') {
            mouvement = deplace_joueur_V(emplacement_P, niveau.tableau, ref.tableau, niveau.h, -1, &niveau.c, &score);
        } else if (touche[0] == 'b' || touche[0] == 's') {
            mouvement = deplace_joueur_V(emplacement_P, niveau.tableau, ref.tableau, niveau.h, 1, &niveau.c, &score);
        }

        if (!mouvement) {
            printf("Mouvement impossible. ");
        }
    }

    time_t temps_fin = time(NULL);

    unsigned long int secondes = difftime(temps_fin, temps_debut);

    unsigned long int minutes = secondes / 60;
    secondes = secondes % 60;

    printf("Bravo ! Vous avez terminé le niveau en %d mouvements !\n", score);
    printf("Vous avez mis %ld minute(s) et %ld seconde(s) pour y arriver.\n\n", minutes, secondes);

    free(emplacement_P);
    free_map(ref);
    free_map(niveau);
}

int main() {

    // Sélection du niveau
    map niveau;
    niveau = selection_level();

    // Grille de référence (contient juste les murs et les points d'intérêt)
    map ref;
    ref = grille_reference(niveau);

    // Jeu
    jeu(niveau, ref);

    printf("Merci d'avoir joué !\n");

    return 0;
}
