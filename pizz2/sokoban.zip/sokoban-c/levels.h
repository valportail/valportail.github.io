#ifndef __LEVELS_H__

#define __LEVELS_H__

typedef struct {
    int l; // Largeur de la grille
    int h; // Hauteur de la grille
    int c; // Nombre de caisses
    char ** tableau;
} map;

map init_map(char * niveau);
map grille_reference(map m);
void free_map(map m);
void affiche_map(map m);
map selection_level();

#endif