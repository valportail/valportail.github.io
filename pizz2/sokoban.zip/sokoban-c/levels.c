#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int l; // Largeur de la grille
    int h; // Hauteur de la grille
    int c; // Nombre de caisses
    char ** tableau;
} map;

map init_map(char * niveau) {  
    int i, j;
    
    char chemin_relatif[25] = "levels/Niveau-";
    char extension[5] = ".txt";

    strcat(chemin_relatif, niveau);
    strcat(chemin_relatif, extension);

    FILE * f = fopen(chemin_relatif, "r");

    map m;

    fscanf(f, "%d", &m.l);
    fscanf(f, "%d", &m.h);
    fscanf(f, "%d", &m.c);

    m.tableau = malloc(m.h * sizeof(char *));
    for (i = 0; i < m.h; i++) {   
        m.tableau[i] = malloc(m.l * sizeof(char));
    }

    fgetc(f);

    for (i = 0; i < m.h; i++) {
        for (j = 0; j < m.l; j++) {
            m.tableau[i][j] = fgetc(f);
        }
        fgetc(f);
    }

    fclose(f);
    return m;
}

map grille_reference(map  m) {
    int i, j;
    map ref;
    ref.h = m.h;
    ref.l = m.l;
    ref.tableau = malloc(m.h * sizeof(char *));
    for(i = 0; i < m.h; i++) {
        ref.tableau[i] = malloc(m.l * sizeof(char));
    }

    for(i = 0; i < m.h; i++) {
        for(j = 0; j < m.l; j++) {
            if (m.tableau[i][j] == '#' || m.tableau[i][j] == 'I') {
                ref.tableau[i][j] = m.tableau[i][j];
            } else {
                ref.tableau[i][j] = ' ';
            }
        }
    }
    return ref;
}

void free_map(map m) {
    int i;
    for(i = 0; i < m.h; i++) {
        free(m.tableau[i]);
    }
    free(m.tableau);
}

void affiche_map(map m) {
    int i, j;
    for(i = 0; i < m.h; i++) {
        for(j = 0; j < m.l; j++) {
            printf("%c", m.tableau[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

map selection_level() {
    char niveau_selectionne[3];

    printf("Veuillez taper le niveau auquel vous voulez jouer : (de 01 à 60, la difficulté augmente avec chaque niveau)\n");
    fgets(niveau_selectionne, 3, stdin);

    map niveau = init_map(niveau_selectionne);
    return niveau;
}