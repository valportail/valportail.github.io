public class MineCell extends Cell {

    //constructor
    public MineCell() {
        super();
    }

    //methods
    public void uncoverCell() {
        if (status == Status.HIDDEN) {
            status = Status.UNCOVERED;
	    }
    }

    public String toString() {
        if (this.getStatus() == Status.HIDDEN) {
            return " ? ";
        } else if (this.getStatus() == Status.MARKED) {
            return " P ";
        } else {
            return " * ";
        }
    }
}
