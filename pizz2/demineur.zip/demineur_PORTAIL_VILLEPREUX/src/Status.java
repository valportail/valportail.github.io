public enum Status {
    HIDDEN, // case caché 
    UNCOVERED, // case découverte
    MARKED // case marqué d'un drapeau
}
