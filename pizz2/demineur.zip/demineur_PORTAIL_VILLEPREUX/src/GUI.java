import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public class GUI implements UI {

    private static final int MAX_SIZE = 200;
    private final JFrame welcomeFrame;
    private final JFrame dialogFrame;
    private final JFrame gameFrame;

    private boolean flagsToggled;

    private static class GUICell extends JButton {
        private int row;
        private int col;

        GUICell(int i, int j) {
            this.row = i;
            this.col = j;
        }
    }

    public GUI() {
        WindowListener l = new WindowAdapter() {
            public void windowClosing(WindowEvent e){
               System.exit(0);
            }
         };

        welcomeFrame = new JFrame("Bienvenue - Démineur");
        welcomeFrame.setLayout(new BoxLayout(welcomeFrame.getContentPane(), BoxLayout.Y_AXIS));
        welcomeFrame.addWindowListener(l);
        welcomeFrame.setSize(640,480);

        dialogFrame = new JFrame("Paramètres de la partie - Démineur");
        dialogFrame.setLayout(new BoxLayout(dialogFrame.getContentPane(), BoxLayout.Y_AXIS));
        dialogFrame.addWindowListener(l);
        dialogFrame.setSize(256,128);

        gameFrame = new JFrame("Partie en cours - Démineur");
        gameFrame.setLayout(new BoxLayout(gameFrame.getContentPane(), BoxLayout.Y_AXIS));
        gameFrame.addWindowListener(l);
        gameFrame.setSize(640,480);

        flagsToggled = false;
    }

    public String welcome() {
        AtomicReference<String> welcomeAction = new AtomicReference<>("");

        JLabel text = new JLabel("Bienvenue dans notre démineur ! Voulez-vous :");
        text.setAlignmentX(Component.CENTER_ALIGNMENT);
        welcomeFrame.add(text);

        JButton newGame = new JButton("Démarrer une nouvelle partie");
        newGame.setAlignmentX(Component.CENTER_ALIGNMENT);
        newGame.addActionListener(e -> welcomeAction.set("N"));
        welcomeFrame.add(newGame);

        JButton loadGame = new JButton("Charger une partie existante");
        loadGame.setAlignmentX(Component.CENTER_ALIGNMENT);
        loadGame.addActionListener(e -> welcomeAction.set("C"));
        welcomeFrame.add(loadGame);

        welcomeFrame.setVisible(true);

        while ("".equals(welcomeAction.get())) {
            if (!welcomeFrame.isVisible()) {
                welcomeFrame.setVisible(true);
            }
        }

        welcomeFrame.setVisible(false);
        return welcomeAction.get();
    }

    public int askValue(String typeOfValue, int min, int max) {
        int v;
        AtomicBoolean valid = new AtomicBoolean(false);

        JLabel text = new JLabel("Entrez le " + typeOfValue + " :");
        text.setAlignmentX(Component.CENTER_ALIGNMENT);
        dialogFrame.add(text);

        JSpinner value = new JSpinner();
        value.setAlignmentX(Component.CENTER_ALIGNMENT);
        dialogFrame.add(value);

        JButton ok = new JButton("Valider");
        ok.setAlignmentX(Component.CENTER_ALIGNMENT);
        ok.addActionListener(e -> {
            if ((int) value.getValue() <= min || (int) value.getValue() >= max) {
                text.setText("Valeur incorrecte, réessayez :");
            } else {
                valid.set(true);
                dialogFrame.setVisible(false);
                dialogFrame.getContentPane().removeAll();
            }
        });
        dialogFrame.add(ok);

        dialogFrame.setVisible(true);

        do {
            v = (int) value.getValue();
        } while (!valid.get());

        return v;
    }

    public int askWidth() {
        return askValue("nombre de colonnes voulues", 0, MAX_SIZE);
    }

    public int askHeight() {
        return askValue("nombre de lignes voulues", 0, MAX_SIZE);
    }

    public int askMinePercentage() {
        return askValue("pourcentage de mines voulu", 0, 100);
    }

    public String[] displayGrid(Grid g, boolean lose) {
        gameFrame.getContentPane().removeAll();

        AtomicBoolean played = new AtomicBoolean(false);
        String[] choices = new String[3];

        // Boutons
        JPanel buttons = new JPanel();
        buttons.setLayout(new FlowLayout());

        JToggleButton flags = new JToggleButton("(Dé)marquer une case", flagsToggled);
        buttons.add(flags);

        JButton save = new JButton("Sauvegarder la partie");
        buttons.add(save);

        if (!lose) {
            flags.addActionListener(e -> flagsToggled = !flagsToggled);

            save.addActionListener(e -> {
                choices[0] = null;
                choices[1] = null;
                choices[2] = "S";
                played.set(true);
            });
        }

        // Grille
        JPanel grid = new JPanel();
        grid.setLayout(new GridLayout(g.getHeight(), g.getWidth()));

        for (int i = 0; i < g.getHeight(); i++) {
            for (int j = 0; j < g.getWidth(); j++) {
                GUICell cell = new GUICell(i, j);

                cell.addActionListener(e -> {
                    choices[0] = String.valueOf(cell.row);
                    choices[1] = String.valueOf(cell.col);
                    if (flagsToggled) {
                        choices[2] = "M";
                    } else {
                        choices[2] = "D";
                    }
                    played.set(true);
                });

                if (lose) {
                    g.getCell(i, j).uncoverCell();
                }

                // Affichage
                if (g.getCell(i, j).isMarked()) { // Case marquée
                    cell.setText("P");
                } else if (g.getCell(i, j).isHidden()) { // Case non découverte
                    cell.setText("");
                } else if (g.getCell(i, j) instanceof MineCell) { // Mine découverte
                    cell.setText("*");
                    cell.setBackground(Color.white);
                } else { // Case libre découverte
                    int nbMinesAround = ((FreeCell) g.getCell(i, j)).getMinesAround();
                    cell.setText(String.valueOf(nbMinesAround));

                    switch (nbMinesAround) {
                        case 1:
                            cell.setBackground(Color.blue);
                            cell.setForeground(Color.white);
                            break;
                        case 2:
                            cell.setBackground(Color.green);
                            cell.setForeground(Color.black);
                            break;
                        case 3:
                            cell.setBackground(Color.red);
                            cell.setForeground(Color.white);
                            break;
                        case 4:
                            cell.setBackground(Color.yellow);
                            cell.setForeground(Color.black);
                            break;
                        case 5:
                            cell.setBackground(Color.magenta);
                            cell.setForeground(Color.black);
                            break;
                        case 6:
                            cell.setBackground(Color.cyan);
                            cell.setForeground(Color.black);
                            break;
                        case 7:
                            cell.setBackground(Color.darkGray);
                            cell.setForeground(Color.white);
                            break;
                        case 8:
                            cell.setBackground(Color.black);
                            cell.setForeground(Color.white);
                            break;
                        default:
                            cell.setBackground(Color.white);
                    }

                    //cell.setEnabled(false);
                }

                grid.add(cell, i, j);
            }
        }

        gameFrame.add(buttons);
        gameFrame.add(grid);

        // Retour
        gameFrame.setVisible(true);

        if (lose) {
            return null;
        } else {
            while (!played.get()) {
                if (!gameFrame.isVisible()) {
                    gameFrame.setVisible(true);
                }
            }

            return choices;
        }
    }

    public void displayMessage(String message) {
        JLabel text = new JLabel(message);
        text.setAlignmentX(Component.CENTER_ALIGNMENT);
        dialogFrame.add(text);

        JButton quit = new JButton("Quitter");
        quit.addActionListener(e -> System.exit(0));
        dialogFrame.add(quit);

        dialogFrame.setVisible(true);
    }

    public void displaySaved() {
        displayMessage("La partie a été sauvegardée avec succès !");
    }

    public void endGame(Grid g, boolean win) {

        if (win) {
            gameFrame.setVisible(false);
            displayMessage("Bravo,vous avez gagné !");
        } else {
            for (int i = 0; i < g.getWidth(); i++) {
                for (int j = 0; j < g.getHeight(); j++) {
                    g.getCell(i, j).uncoverCell();
                }
            }

            displayGrid(g, true);
            displayMessage("Dommage, vous avez perdu.");
        }
    }
}