public class FreeCell extends Cell {

    //attribute
    private int minesAround;
    
    //constructor
    public FreeCell() {
        super();
        minesAround = 0;
    }

    //methods
    public int getMinesAround() {
        return minesAround;
    }

    /* Permet de mettre à jour le nombre de mines autour d'une case */
    public void updateMinesAround() {
        for (Direction d : Direction.values()) {
            Cell c = this.getNeighbor(d);
            if (c instanceof MineCell) {
                this.minesAround++;
            }
        }
    }

    public void uncoverCell() {
        if (this.getStatus() == Status.HIDDEN) {
            status = Status.UNCOVERED;
            if (minesAround == 0) {
                for (Cell neighbor : neighbors.values()) {
                    neighbor.uncoverCell();
                }
            }
        }
    }

    public String toString() {
        if (this.status == Status.HIDDEN) {
            return " ? ";
        } else if (this.status == Status.MARKED) {
            return " P ";
        } else {
            switch (this.getMinesAround()) {
                case 1: return "\033[44m 1 \033[00m";
                case 2: return "\033[42m 2 \033[00m";
                case 3: return "\033[41m 3 \033[00m";
                case 4: return "\033[43m 4 \033[00m";
                case 5: return "\033[45m 5 \033[00m";
                case 6: return "\033[46m 6 \033[00m";
                case 7: return "\033[40m 7 \033[00m";
                case 8: return "\033[47m 8 \033[00m";
                default: return " 0 ";
            }
        }
    }
}

