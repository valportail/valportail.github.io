public interface UI {
    String welcome();

    int askWidth();
    int askHeight();
    int askMinePercentage();

    String[] displayGrid(Grid g, boolean lose);

    void displaySaved();

    void endGame(Grid g, boolean win);
}

