import java.util.EnumMap;

public abstract class Cell {

    //attributes
    protected Status status;
    protected EnumMap<Direction, Cell> neighbors;

    //constructor
    public Cell() {
        this.status = Status.HIDDEN;
        this.neighbors = new EnumMap<>(Direction.class);
    }
    
    // Methods
    public Status getStatus(){
	    return this.status;
    }

    public void setStatus(Status s){
	this.status = s;
    }

    public boolean isHidden(){
	    return this.status == Status.HIDDEN;
    }

    public boolean isUncovered(){
	    return this.status == Status.UNCOVERED;
    }

    public boolean isMarked(){
	    return this.status == Status.MARKED;
    }

    /* Permet de changer le status de la case entre poser/déposer un drapeau */
    public void toggleMarkCell(){
        if (isMarked()) {
            this.status = Status.HIDDEN;
        } else if (isHidden()) {
            this.status = Status.MARKED;
        }
    }

    /* permet de déminer/découvrir une case */
    public abstract void uncoverCell();

    /* Permet de faire un affichage différent selon le status et le nombre de voisins de la case */
    public abstract String toString();

    /* Permet d'obtenir le voisin de la case à partir d'une direction  */
    public Cell getNeighbor(Direction d) {
        return this.neighbors.get(d);
    }

    /* Permet de faire le chaînage entre 2 cellules selon la direction donnée */
    private void addLink(Cell other, Direction d) {
        // Le chaînage est réciproque, car le tableau est doublement chaîné.
        
        this.neighbors.put(d, other);
        if (other != null) {
            other.neighbors.put(d.opposite(), this);
        }
    }

    /* Permet d'ajouter les voisins entre 2 cellules selon la direction donnée */
    public void addNeighbor(Cell other, Direction d) {
        // Chaînage direct entre les 2 cellules
        this.addLink(other, d);

        if (!d.isCorner()) {
            int[] shifts1 = {-2, 0, 0, 2};
            int[] shifts2 = {2, 0, 0, -2};

            Cell c1 = this;
            Cell c2 = this;

            for (int i = 0; i < 4; i++) {
                if (c1 != null) {
                    c1.addLink(other, d.shift(i));
                    c1 = c1.getNeighbor(d.shift(shifts1[i]));
                }

                if (c2 != null) {
                    c2.addLink(other, d.shift(i));
                    c2 = c2.getNeighbor(d.shift(shifts2[i]));
                }
            }
        }
    }
}
