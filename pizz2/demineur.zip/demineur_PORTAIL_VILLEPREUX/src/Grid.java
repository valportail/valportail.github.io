import java.util.ArrayList;
import java.util.Random;

class Grid {
    // attributs
    private final int height;
    private final int width;
    private final int nbMines;
    private Cell gridStart;

    // Constructors
    Grid(int h, int w, int percentMines) {
        this.height = h;
        this.width = w;
        this.nbMines = (int) ((h * w) * (percentMines / 100.0));
        this.buildGrid();
    }

    /* Permet de construire la grille en connaissant les mines au préalable.
       Utilité pour le chargement depuis un fichier */
    Grid(int h, int w, int percentMines, ArrayList<int[]> mines) {
        this.height = h;
        this.width = w;
        this.nbMines = (int) ((h * w) * (percentMines / 100.0));
        this.buildGrid(mines);
    }



    // Accesseurs

    public int getHeight() {
        return this.height;
    }

    public int getWidth() {
        return this.width;
    }

    public int getNbMines() {
        return this.nbMines;
    }
    /* Permet de connaître la cellule si on lui passe en paramètre les indices
        de la case voulu */ 
    public Cell getCell(int i, int j) {
        if ((i < 0 || i > this.getHeight()) || (j < 0 || j > this.getWidth())) {
            return null;
        }

        Cell c = this.gridStart;

        for (int x = 0; x < i; x++) {
            c = c.getNeighbor(Direction.S);
        }

        for (int y = 0; y < j; y++) {
            c = c.getNeighbor(Direction.E);
        }

        return c;
    }

    // Méthodes

    /* Permet de savoir si les coordonnées entrées sont celle d'une mine ou pas */
    public static boolean coordInMines(int[] coord, ArrayList<int[]> mines) {
        for (int[] k : mines) {
            if (k[0] == coord[0] && k[1] == coord[1]) {
                return true;
            }
        }
        return false;
    }

    /* Permet de construire la grille, en faisant le chaînage. On part de la
    cellule nommée gridStart, situé en haut à gauche. Un tableau n'est PAS
    utilisé pour stocker les cellules, car il n'y en a pas besoin.
    Les mines sont placées aléatoirement.*/
    public void buildGrid(ArrayList<int[]> mines) {
        // Construction de la grille
        Cell newCell;
        int[] coordCell = new int[2];
        for (int i = 0; i < this.getHeight(); i++) {
            for (int j = 0; j < this.getWidth(); j++) {
                coordCell[0] = i;
                coordCell[1] = j;
                if (coordInMines(coordCell, mines)) {
                    newCell = new MineCell();
                } else {
                    newCell = new FreeCell();
                }
                if (i == 0 && j == 0) {
                    this.gridStart = newCell;
                } else {
                    if (j == 0) {
                        this.getCell(i-1, 0).addNeighbor(newCell, Direction.S);
                    } else {
                        this.getCell(i, j-1).addNeighbor(newCell, Direction.E);
                    }
                }
            }
        }

        // Mise à jour des nombres de mines
        for (int i = 0; i < this.getHeight(); i++) {
            for (int j = 0; j < this.getWidth(); j++) {
                if (this.getCell(i, j) instanceof FreeCell) {
                    ((FreeCell) this.getCell(i, j)).updateMinesAround();
                }
            }
        }
    }

    /* Idem, mais le tableau de mines n'est pas connu à l'avance (cas d'une nouvelle grille) */
    public void buildGrid() {
        // Tableau qui contiendra toutes les coordonnées des mines
        Random rd = new Random();
        ArrayList<int[]> mines = new ArrayList<>();

        for (int k = 0; k < this.getNbMines(); k++) {
            int[] mine = new int[2];
            do {
                mine[0] = rd.nextInt(this.getHeight());
                mine[1] = rd.nextInt(this.getWidth());
            } while (coordInMines(mine, mines)); // S'il y a déjà une mine sur cette case
            mines.add(mine);
        }

        buildGrid(mines);
    }

    /* Permet d'afficher la grille.
    Lorsque le booléen uncoverAll est vrai, toutes les cases de la grille sont découvertes
    (Cas où la partie est terminée)
    */
    public void display(boolean uncoverAll) {
        System.out.println();
        System.out.print("    ");
        for (int i = 0; i < this.getWidth(); i++) {
            System.out.print(" " + (char) ('A' + i) + " ");
        }
        System.out.println();

        System.out.print("    ");
        for (int i = 0; i < this.getWidth(); i++) {
            System.out.print("___");
        }
        System.out.println();

        for (int row = 0; row < this.getHeight(); row++) {
            String lineNumber = String.format("%2d", row + 1);
            System.out.print(lineNumber + " |");

            for (int col = 0; col < this.getWidth(); col++) {
                if (uncoverAll) {
                    this.getCell(row, col).uncoverCell();
                }
                System.out.print(this.getCell(row, col).toString());
            }

            System.out.println("|");
        }

        System.out.print("    ");
        for (int i = 0; i < this.getWidth(); i++) {
            System.out.print("¯¯¯");
        }
        System.out.println();
    }

    /* Permet d'afficher la grille */
    public void display() {
        display(false);
    }
}
