import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.ArrayList;

class GridFileManager {
    private final Grid grid;

    // Constructeurs
    GridFileManager (Grid grid) {
        this.grid = grid;
    }

    GridFileManager (Path filePath) {
        this.grid = load(filePath);
    }

    // Méthodes

    public Grid getGrid(){
	return this.grid;
    }

    /* Permet de sauvegarder l'état de la grille actuelle */
    public void save(Path filePath) {
        try (PrintWriter writer = new PrintWriter(Files.newBufferedWriter(filePath))) {
            writer.println(this.grid.getHeight());
            writer.println(this.grid.getWidth());
            writer.println(this.grid.getNbMines());

            for (int i = 0; i < this.grid.getHeight(); i++) {
                for (int j = 0; j < this.grid.getWidth(); j++) {
		    
                    Cell cell = this.grid.getCell(i, j);
                    if (cell instanceof MineCell) {
                        writer.print("M");
                    } else {
                        writer.print(((FreeCell) cell).getMinesAround());
                    }
                    if (cell.isHidden()) {
                        writer.print("H");
                    } else if (cell.isMarked()) {
                        writer.print("F");
                    } else {
                        writer.print("U");
                    }
                    writer.print(" ");
                }
                writer.println();
            }
        } catch (IOException e) {
            System.err.println("Erreur lors de l'écriture dans le fichier " + filePath);
        }
    }

    /* Permet de charger la grille depuis le chemin indiqué */ 
    public static Grid load(Path filePath) {
        try {
            List<String> lines = Files.readAllLines(filePath);
            int h = Integer.parseInt(lines.get(0));
            int w = Integer.parseInt(lines.get(1));
            int nbMines = Integer.parseInt(lines.get(2));
	    int percentMines = (int)(nbMines * 100.0)/(h*w);
	    lines.remove(0);
	    lines.remove(0);
	    lines.remove(0);

	    ArrayList<int[]> minesCoords = getMineCoords(h, w, lines);
	    
	    Grid grid = new Grid(h, w, percentMines, minesCoords);
	    updateStatus(grid, lines);
	    
	    return grid;
        } catch (IOException e) {
            System.err.println("Erreur lors de la lecture du fichier: " + filePath);
	    return null;
        }
    }

    /* Permet de connaitre les coordonnées de chaque mine depuis les lignes du
    fichier */
    public static ArrayList<int[]> getMineCoords(int h, int w, List<String> lines){
	ArrayList<int[]> mineCoords = new ArrayList<>();
        for (int i = 0; i < h; i++) {
            String[] row = lines.get(i).split(" ");
            for (int j = 0; j < w; j++) {
                if (row[j].startsWith("M")) {
		    mineCoords.add(new int[] {i, j});
		}
            }
        }
	return mineCoords;
    }

    /* Permet de mettre à jour le statut de chaque case, en fonction des lignes
    du fichier */
    public static void updateStatus(Grid grid, List<String> lines){
	for (int i = 0; i < grid.getHeight(); i++) {
            String[] row = lines.get(i).split(" ");
            for (int j = 0; j < grid.getWidth(); j++) {
                Cell cell = grid.getCell(i, j);
                char status = row[j].charAt(1);
                switch (status) {
                    case 'H' : 
                    	cell.setStatus(Status.HIDDEN);
                    	break;
                    
                    case 'U' :
                    	cell.setStatus(Status.UNCOVERED);
                    	break;
                    case 'F' : 
                    	cell.setStatus(Status.MARKED);
                    	break;
                    default : 
                    	throw new IllegalArgumentException("Statut de cellule invalide: " + status);
                }
            }
        }
    }
}
