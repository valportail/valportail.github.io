public enum Direction {
    N, 
    NE, 
    E, 
    SE, 
    S, 
    SW,
    W, 
    NW;

    /* Retourne la direction "o" case après (dans le sens horaire) */
    public Direction shift(int o) {
        return Direction.values()[(this.ordinal() + o) % 8];
    }

    /* Retourner la direction opposée à la case */
    public Direction opposite() {
        return this.shift(4);
    }

    /* Permet de savoir si une direction est un angle ou pas */
    public boolean isCorner() {
        return this.ordinal() % 2 != 0;
    }
}
