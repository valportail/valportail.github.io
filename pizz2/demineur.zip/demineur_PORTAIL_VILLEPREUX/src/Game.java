import java.util.Scanner;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Game {

    public Grid grid;
    public UI ui;

    public Game() {
	String choix = "";
        Scanner scanner = new Scanner(System.in);

	displayLoadGameStart();
        while (!choix.equalsIgnoreCase("T") && !choix.equalsIgnoreCase("G")) {
            System.out.print("Voulez vous jouer en mode:\n\t[T] Terminal\n\t[G] Graphique\n-->  ");
            choix = scanner.nextLine();
        }
	if (choix.equalsIgnoreCase("T")) {
            this.ui = new  TUI();
        } else {
            this.ui = new GUI();
        }
	displayLoadGameEnd();

        String action = ui.welcome();
        if (action.equalsIgnoreCase("N")) {
            int height = ui.askHeight();
            int width = ui.askWidth();
            int minePercentage = ui.askMinePercentage();
            this.grid = new Grid(height, width, minePercentage);
        }
        if (action.equalsIgnoreCase("C")) {
            Path filePathL = Paths.get("../saveGrid/grid.txt");
            GridFileManager gridFileL = new GridFileManager(filePathL);
            this.grid = gridFileL.getGrid();
        }
    }

    /* Permet de lancer une partie */
    public void play() {
        boolean mineMined = false;
        boolean saved = false;

        do {
            String[] choices =  ui.displayGrid(this.grid, false);
            if ("S".equals(choices[2])) {
                GridFileManager gridFileS = new GridFileManager(this.grid);
                Path filePathS = Paths.get("../saveGrid/grid.txt");
                gridFileS.save(filePathS);
                ui.displaySaved();
                saved = true;
            } else {
                mineMined = updateGrid(choices[0], choices[1], choices[2]);
            }
        } while (!checkEndGame() && !mineMined && !saved);

        if (!saved) {
            ui.endGame(this.grid, !mineMined);
        }
    }

    /* Met à jour grille, en prenant en compte le choix de l'utilisateur*/
    public boolean updateGrid(String r, String c, String action) {
        int col = Integer.parseInt(c);
        int row = Integer.parseInt(r);

        Cell currentCell = this.grid.getCell(row, col);
        boolean lost = false;

        switch (action) {
            case "M":
                currentCell.toggleMarkCell();
                break;
            case "D":
                if (!currentCell.isMarked()) {
                    currentCell.uncoverCell();
                    if (currentCell instanceof MineCell) {
                        lost = true;
                    }
                }
                break;
            default:
                System.out.println("Action invalide");
        }

        return lost;
    }

    /* Vérifie si la partie est terminé */
    public boolean checkEndGame() {
        boolean allNonMinesUncoveredOrMarked = true;
        boolean mineUncovered = false;

        for (int i = 0; i < grid.getHeight(); i++) {
            for (int j = 0; j < grid.getWidth(); j++) {
                Cell cell = grid.getCell(i, j);
                if (cell instanceof MineCell && cell.isUncovered()) {
                    mineUncovered = true;
                } else if (!(cell instanceof MineCell) && (!cell.isUncovered() && !cell.isMarked())) {
                    allNonMinesUncoveredOrMarked = false;
                }
            }
        }
        return mineUncovered || allNonMinesUncoveredOrMarked;
    }

    private void displayLoadGameStart(){
	System.out.println("---------------------------------------------");
	System.out.println("Configuration du jeu en cours...");
	System.out.println(".....................");
	System.out.println("...........");
    }

    private void displayLoadGameEnd(){
	System.out.println("Votre choix a bien été pris en compte...");
	System.out.println("---------------------------------------------");
	System.out.print("\033[H\033[2J");
    }
}
