import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class TUI implements UI {
	/* Permet d'ajouter des lignes, peut import le système d'exploitation*/
	public void addBlank() {
		System.out.println(System.getProperty("line.separator") + System.getProperty("line.separator"));
	}

	/* Permet de nettoyer pour afficher la prochaine ligne tout en haut du terminal*/
	public void cleanTerminal() {
		System.out.print("\033[H\033[2J");
		// Vide le buffer
		System.out.flush();
	}

	/* Message de bienvenue
	Demande à l'utilisateur s'il veut charger une partie existante, ou créer
    une nouvelle partie*/
	public String welcome() {
		addBlank();

		System.out.println("Bonjour et bienvenue dans notre superbe jeu du démineur !");
		System.out.println("Souhaitez-vous: \n[C] Charger une partie existante; \n[N] Démarrer une nouvelle partie;\n");

		String action;
		Scanner scanner = new Scanner(System.in);
		do {
			System.out.print("--> ");
			action = scanner.nextLine().toUpperCase();
		} while (!action.equalsIgnoreCase("C") && !action.equalsIgnoreCase("N"));
		return action;
	}

	/* Permet de demander à l'utilisateur le nombre de colonnes voulu */
	public int askWidth() {
		int width = -1;
		Scanner scanner = new Scanner(System.in);
		do {
			try {
				System.out.print("Entrez le nombre de colonnes voulues (1 - 26): ");
				String input = scanner.nextLine();
				width = Integer.parseInt(input);
				if (width <= 0 || width > 26) {
					System.out.println("Entrée invalide. Entrez un nombre positif (1 - 26).");
				}
			} catch (NumberFormatException e) {
				System.out.println("Entrée invalide. Entrez un nombre positif.");
			}
		} while (width <= 0 || width > 26);
		return width;
	}

	/* Permet de demander à l'utilisateur le nombre de lignes voulu */
	public int askHeight() {
		int height = -1;
		Scanner scanner = new Scanner(System.in);
		do {
			try {
				System.out.print("Entrer le nombre de lignes voulues : ");
				String input = scanner.nextLine();
				height = Integer.parseInt(input);
				if (height <= 0) {
					System.out.println("Entrée invalide. Entrez un nombre positif.");
				}
			} catch (NumberFormatException e) {
				System.out.println("Entrée invalide. Entrez un nombre positif.");
			}
		} while (height <= 0);
		return height;
	}

	/* Permet de demander à l'utilisateur le pourcentage de mine voulu */
	public int askMinePercentage() {
		Scanner scanner = new Scanner(System.in);
		int minePercentage = 0;
		boolean validInput = false;
		do {
			System.out.print("Entrez le pourcentage de mines voulu (0-100%): ");
			if (scanner.hasNextInt()) {
				minePercentage = scanner.nextInt();
				if (minePercentage < 0 || minePercentage > 100) {
					System.out.println("Entrée invalide. Veuillez entrer un nombre entre 0 et 100.");
				} else {
					validInput = true;
				}
			} else {
				System.out.println("Entrée invalide. Veuillez entrer un nombre entre 0 et 100.");
				scanner.nextLine();
			}
		} while (!validInput);
		return minePercentage;
	}

	/* Affiche la grille et gère les saisies de l'utilisateur */
	public String[] displayGrid(Grid g, boolean lose) {
		cleanTerminal();
		if (lose) {
			g.display(true);
			return null;
		} else {
			g.display();

			Scanner scanner = new Scanner(System.in);
			boolean validInputCell = false;
			int row = 0;
			String column = null;
			String action;

			do {
				System.out.print(
						"Souhaitez-vous: \n[M] Marquer/démarquer une case avec un drapeau; \n[D] Dévoiler une case; \n[S] Sauvegarder la partie en cours;\n");
				action = scanner.nextLine().toUpperCase();
			} while (!action.equalsIgnoreCase("M") && !action.equalsIgnoreCase("D") && !action.equalsIgnoreCase("S"));

			if (action.equalsIgnoreCase("S")) {
				GridFileManager gridFileS = new GridFileManager(g);
				Path filePathS = Paths.get("../saveGrid/grid.txt");
				gridFileS.save(filePathS);

				return new String[] {null, null, "S"};
			} else {
				do {
					System.out.print("Entrez la case à sélectionner (ex: A-3) : ");
					String cell = scanner.nextLine().toUpperCase();
					String[] parts = cell.split("-");
					if (parts.length == 2) {
						column = parts[0];
						row = Integer.parseInt(parts[1]);
						if (column.matches("[A-" + (char) ('A' + g.getWidth() - 1) + "]") && row >= 1
								&& row <= g.getHeight()) {
							validInputCell = true;
						} else {
							System.out.println("Case invalide, veuillez réessayer.");
						}
					} else {
						System.out.println("Case invalide, veuillez réessayer.");
					}
				} while (!validInputCell);

				return new String[]{String.valueOf(row - 1), String.valueOf(column.charAt(0) - 'A'), action};
			}
		}
	}

	public void displaySaved() {
		System.out.println("La partie a été sauvegardée avec succès.\n A bientôt !");
		System.exit(0);
	}

	/* Message de fin de partie */
    public void endGame(Grid g, boolean win) {
		cleanTerminal();
		if (win) {
			System.out.println("Félicitations, vous avez gagné !");
		} else {
			System.out.println("Dommage, vous avez perdu.");
			displayGrid(g, true);
		}
		System.exit(0);
	}
}
